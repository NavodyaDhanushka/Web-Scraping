package com.example.Q03.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LotteryDto {
    private String url;
    private String name;
}
